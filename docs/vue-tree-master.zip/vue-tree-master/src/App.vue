<template>
  <h1>welcome to vue-tree-halower</h1>
</template>
<script>
export default {
  name: 'vue-tree'
}
</script>
